$(document).ready(function () {
    $("#contactForm").on("submit", function (event) {
        event.preventDefault();
        const name = $("#name").val().trim();
        const email = $("#email").val().trim();
        const message = $("#message").val().trim();

        if (name && email && message) {
            alert("Thank you, " + name + "! We will contact you soon.");
            $("#responseMessage").text("Thank you, " + name + "! We will contact you soon.");
        } else {
            alert("Please fill out all fields.");
            $("#responseMessage").text("Please fill out all fields.");
        }
    });
});