$(document).ready(function () {
    // Initialize an empty cart
    const cartItems = [];
    const $cartList = $("#cart-items");  // List to display cart items
    const $totalPriceElement = $("#total-price");  // Total price display
    const $responseMessage = $("#responseMessage");  // Response message element

    // Function to update the cart display
    function updateCart() {
        $cartList.empty(); // Clear the existing cart items
        let totalPrice = 0;

        // Loop through each cart item and append it to the cart
        cartItems.forEach(item => {
            const listItem = `<li>${item.name} - ₹${item.price}</li>`;  // Using template literals
            $cartList.append(listItem);
            totalPrice += item.price; // Calculate total price
        });

        // Update total price in the UI
        $totalPriceElement.text(`Total: ₹${totalPrice.toFixed(2)}`);  // Using template literals
    }

    // Add to Cart functionality
    $(".add-to-cart").on("click", function () {
        const $product = $(this).closest(".product");
        const id = $product.data("id");
        const name = $product.data("name");
        const price = parseFloat($product.data("price"));

        // Add the product to the cart array
        cartItems.push({ id, name, price });
        updateCart(); // Update the cart UI

        // Notify the user
        alert(`${name} has been added to your cart!`);  // Using template literals
        $responseMessage.text(`${name} has been added to your cart!`);  // Update the response message
    });

    // Buy Now functionality
    $(".buy-now").on("click", function () {
        // Open the modal
        $("#buyNowModal").css("display", "block");
    });

    // Close modal when user clicks on <span> (x)
    $(".close").on("click", function () {
        $("#buyNowModal").css("display", "none");
    });

    // Close modal when user clicks anywhere outside the modal
    $(window).on("click", function (event) {
        if ($(event.target).hasClass("modal")) {
            $("#buyNowModal").css("display", "none");
        }
    });

    // Form submission handling
    $("#buyNowForm").on("submit", function (event) {
        event.preventDefault();
        // Process the form data
        const buyerName = $("#buyerName").val().trim();
        const buyerEmail = $("#buyerEmail").val().trim();
        const buyerAddress = $("#buyerAddress").val().trim();

        // Display a thank you message (for now)
        alert(`Thank you, ${buyerName}! Your purchase is being processed.`);

        // Close the modal
        $("#buyNowModal").css("display", "none");

        // Optionally, send the form data to the server via AJAX (not implemented here)
    });
});