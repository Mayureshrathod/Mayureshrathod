document.addEventListener("DOMContentLoaded", function () {
    const aboutContent = document.getElementById("about-content");

    const aboutData = [
        {
            title: "Our Story",
            text: "Fashion World started with a vision to provide quality, stylish, and affordable clothing to everyone. Founded in 2020, we have grown into a trusted brand for trendsetters worldwide."
        },
        {
            title: "Our Mission",
            text: "Our mission is to redefine fashion by offering versatile and eco-friendly apparel that aligns with modern lifestyles while promoting sustainability."
        },
        {
            title: "Why Choose Us?",
            text: "At Fashion World, we prioritize customer satisfaction, ethical sourcing, and innovative designs. We believe in making a difference through fashion."
        }
    ];

    aboutData.forEach(section => {
        const sectionDiv = document.createElement("div");
        sectionDiv.classList.add("about-section");

        const title = document.createElement("h2");
        title.textContent = section.title;

        const paragraph = document.createElement("p");
        paragraph.textContent = section.text;

        sectionDiv.appendChild(title);
        sectionDiv.appendChild(paragraph);
        aboutContent.appendChild(sectionDiv);
    });
});